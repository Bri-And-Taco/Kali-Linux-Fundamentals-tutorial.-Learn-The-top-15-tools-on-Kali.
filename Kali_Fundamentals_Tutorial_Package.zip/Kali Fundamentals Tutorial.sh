#!/usr/bin/env bash
# Kali Fundamentals — Interactive Tutorial
# Purpose: Guided learning script. DOES NOT auto-install tools.
# Author: Kalitech (for Broker)
# Usage: chmod +x kali_tutorial.sh && ./kali_tutorial.sh
# Safety: Run only in a controlled lab (VMs, containers, private network). Do NOT target public networks.

set -euo pipefail
IFS=$'\n\t'

# ---- Edit these before running ----
LAB_TARGET="192.168.56.101"     # <-- Change to your lab VM IP
LAB_INTERFACE="eth0"            # <-- Adjust to your VM network interface
SAMPLE_HASH_FILE="./sample_hashes.txt"
# -----------------------------------

pause() {
  read -r -p $'\nPress Enter to continue...'
}

header() {
  clear
  echo "KALI FUNDAMENTALS — INTERACTIVE TUTORIAL"
  echo "Lab target: $LAB_TARGET | Interface: $LAB_INTERFACE"
  echo "Run in an isolated environment only."
  echo
}

print_install_instructions() {
  local pkg="$1"
  local notes="$2"
  echo
  echo "INSTALLATION GUIDANCE for: $pkg"
  echo "--------------------------------"
  echo "Manual install suggestions (pick one):"
  echo "1) apt (Kali repos):"
  echo "   sudo apt update && sudo apt install -y $pkg"
  echo "2) snap / upstream / package page - visit upstream for latest builds."
  echo "3) git clone if available and build from source (recommended for latest):"
  echo "   git clone <repo-url> && cd <repo> && ./configure && make && sudo make install"
  if [[ -n "$notes" ]]; then
    echo
    echo "Notes: $notes"
  fi
  echo
  echo "After manual install run: which $pkg  OR  $pkg --version  to verify."
}

verify_installed() {
  local bin="$1"
  if command -v "$bin" >/dev/null 2>&1; then
    echo "VERIFIED: $bin found at $(command -v $bin)"
    return 0
  else
    echo "MISSING: $bin not in PATH. Install manually and re-run verification."
    return 1
  fi
}

section_nmap() {
  echo
  echo "=== TOOL: nmap ==="
  echo "Overview: Network mapper for discovery and port/service enumeration."
  echo "Primary uses: host discovery, port scanning, service/version detection, NSE scripts for enumeration."
  print_install_instructions "nmap" "Nmap includes many NSE scripts for automation. Learn 'nmap -sV --script=default' usage."
  pause

  echo
  echo "BASIC EXAMPLES"
  echo "1) Host discovery (ping sweep):"
  echo "   nmap -sn ${LAB_TARGET%.*}.0/24"
  echo
  echo "2) Top ports and service detection:"
  echo "   nmap -sS -sV -T4 -p- $LAB_TARGET"
  echo
  echo "3) NSE script example (http-enum):"
  echo "   nmap -p 80,8080 --script=http-enum $LAB_TARGET"
  echo
  echo "GUIDED EXERCISES"
  echo "A) Run a safe scan against your lab target. Record open ports and services."
  echo "   Action: run 'nmap -sV -p- -T4 $LAB_TARGET' and save results to nmap_full.txt"
  echo "B) Try scanning the /24 network to locate other lab hosts."
  pause
  verify_installed nmap || true
}

section_netcat() {
  echo
  echo "=== TOOL: netcat (nc) ==="
  echo "Overview: Swiss-army TCP/UDP connection tool. Useful for banner grabbing, simple listeners, and file transfer."
  print_install_instructions "netcat" "nc can be traditional or 'ncat' from nmap suite. Check manpage for features."
  pause

  echo
  echo "BASIC EXAMPLES"
  echo "1) Banner grab a service:"
  echo "   nc -vz $LAB_TARGET 22"
  echo
  echo "2) Create a simple TCP listener (receiver):"
  echo "   nc -lvp 9001 > received.bin"
  echo "   Sender on other host: nc <listener_ip> 9001 < file.bin"
  echo
  echo "GUIDED EXERCISES"
  echo "A) On your host start a listener: nc -lvp 4444"
  echo "   From lab VM: nc <host_ip> 4444"
  echo "   Type messages to verify connectivity."
  pause
  verify_installed nc || verify_installed netcat || true
}

section_tcpdump() {
  echo
  echo "=== TOOL: tcpdump ==="
  echo "Overview: Packet capture and analysis from the terminal. Good for quick captures and filters."
  print_install_instructions "tcpdump" "Use -i $LAB_INTERFACE to capture on correct interface. Run as root or with sudo."
  pause

  echo
  echo "BASIC EXAMPLES"
  echo "1) Capture 100 packets to a pcap file:"
  echo "   sudo tcpdump -i $LAB_INTERFACE -c 100 -w capture.pcap"
  echo
  echo "2) Filter by host and port:"
  echo "   sudo tcpdump -i $LAB_INTERFACE host $LAB_TARGET and port 80 -w http_traffic.pcap"
  echo
  echo "GUIDED EXERCISES"
  echo "A) Capture a short trace while you curl a web page on the lab VM:"
  echo "   On host: sudo tcpdump -i $LAB_INTERFACE -w curl_trace.pcap"
  echo "   On lab VM: curl http://$LAB_TARGET"
  echo "   Stop capture after."
  echo "B) Open the capture in Wireshark for layered analysis."
  pause
  verify_installed tcpdump || true
}

section_wireshark() {
  echo
  echo "=== TOOL: Wireshark (or tshark) ==="
  echo "Overview: Graphical protocol analyzer. tshark is CLI equivalent."
  print_install_instructions "wireshark" "GUI needs X. tshark is useful in headless environments: sudo apt install -y tshark"
  pause

  echo
  echo "BASIC EXAMPLES"
  echo "1) Launch GUI (desktop): wireshark &"
  echo "2) CLI capture with tshark:"
  echo "   sudo tshark -i $LAB_INTERFACE -c 200 -w tshark_capture.pcap"
  echo
  echo "GUIDED EXERCISES"
  echo "A) Open the tcpdump capture from earlier in Wireshark. Use follow TCP stream to view HTTP content."
  echo "B) Use display filters: http.request.method == \"GET\""
  pause
  verify_installed wireshark || verify_installed tshark || true
}

section_metasploit() {
  echo
  echo "=== TOOL: Metasploit Framework (msfconsole) ==="
  echo "Overview: Exploit development and post-exploitation framework. Use only in lab."
  print_install_instructions "metasploit-framework" "Metasploit is large. For beginners use msfconsole while reading module descriptions."
  pause

  echo
  echo "BASIC EXAMPLES"
  echo "1) Start console:"
  echo "   sudo msfdb init && msfconsole"
  echo
  echo "2) Search modules (example):"
  echo "   search name:vsftp type:exploit"
  echo
  echo "GUIDED EXERCISES"
  echo "A) Use auxiliary/scanner/ssh/ssh_version to fingerprint SSH on lab target."
  echo "   use auxiliary/scanner/ssh/ssh_version"
  echo "   set RHOSTS $LAB_TARGET"
  echo "   run"
  echo "B) Read module docs before attempting any exploit. Log everything."
  pause
  verify_installed msfconsole || true
}

section_john_hashcat() {
  echo
  echo "=== TOOLS: john (John the Ripper) and hashcat ==="
  echo "Overview: Password-cracking tools. john is easier to start. hashcat uses GPU acceleration."
  print_install_instructions "john, hashcat" "Ensure sample hashes are from your lab and legal. Use curated rules and wordlists (rockyou.txt)."
  echo
  cat > "$SAMPLE_HASH_FILE" <<'EOF'
# sample SHA1: 'password' (lab only)
5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8
EOF
  echo "Created $SAMPLE_HASH_FILE with lab sample hashes."
  pause

  echo
  echo "BASIC EXAMPLES"
  echo "1) john usage (single core):"
  echo "   john --wordlist:/usr/share/wordlists/rockyou.txt $SAMPLE_HASH_FILE"
  echo
  echo "2) hashcat usage (example):"
  echo "   hashcat -m 100 -a 0 $SAMPLE_HASH_FILE /usr/share/wordlists/rockyou.txt"
  echo
  echo "GUIDED EXERCISES"
  echo "A) Run john against sample_hashes.txt and note cracked passwords."
  echo "B) Compare john vs hashcat speed (if GPU available)."
  pause
  verify_installed john || verify_installed hashcat || true
}

section_hydra() {
  echo
  echo "=== TOOL: hydra ==="
  echo "Overview: Fast network logon cracker for many protocols. Use responsibly in lab only."
  print_install_instructions "hydra" "Hydra supports combinations of username/password lists and many protocols."
  pause

  echo
  echo "BASIC EXAMPLES"
  echo "1) FTP brute force (lab only):"
  echo "   hydra -l test -P /usr/share/wordlists/rockyou.txt ftp://$LAB_TARGET"
  echo
  echo "GUIDED EXERCISES"
  echo "A) Against a deliberately configured lab service try 10 attempts. Log outcomes."
  pause
  verify_installed hydra || true
}

section_burp_sqlmap() {
  echo
  echo "=== TOOLS: Burp Suite (Community) & sqlmap ==="
  echo "Overview: Burp is an intercepting proxy. sqlmap automates SQL injection discovery and exploitation."
  print_install_instructions "burpsuite, sqlmap" "For Burp use Community edition for learning. Configure browser proxy to 127.0.0.1:8080."
  pause

  echo
  echo "BASIC EXAMPLES"
  echo "1) Start Burp then configure browser proxy to intercept requests."
  echo "2) Use sqlmap against a lab SQLi URL:"
  echo "   sqlmap -u 'http://$LAB_TARGET/vuln.php?id=1' --batch --dbs"
  echo
  echo "GUIDED EXERCISES"
  echo "A) Intercept a login POST with Burp, examine parameters, and learn to tamper safely."
  echo "B) Run sqlmap against a purposely vulnerable lab app. Capture and log output."
  pause
  verify_installed burpsuite || verify_installed sqlmap || true
}

section_aircrack_ettercap() {
  echo
  echo "=== TOOLS: aircrack-ng & Ettercap ==="
  echo "Overview: aircrack-ng suite for wireless auditing. Ettercap for man-in-the-middle on switched/networks in lab."
  print_install_instructions "aircrack-ng, ettercap" "Wireless work requires a compatible adapter and appropriate drivers."
  pause

  echo
  echo "BASIC EXAMPLES"
  echo "1) Monitor mode setup (example):"
  echo "   sudo ip link set $LAB_INTERFACE down"
  echo "   sudo iw dev $LAB_INTERFACE set type monitor"
  echo "   sudo ip link set $LAB_INTERFACE up"
  echo
  echo "2) Capture handshakes and use aircrack-ng to crack (lab-only capture):"
  echo "   airodump-ng -w capture --bssid <BSSID> $LAB_INTERFACE"
  echo "   aircrack-ng capture-01.cap -w /usr/share/wordlists/rockyou.txt"
  echo
  echo "GUIDED EXERCISES"
  echo "A) Practice monitor mode in an isolated wireless lab. Capture and analyze with Wireshark."
  pause
  verify_installed aircrack-ng || verify_installed ettercap || true
}

section_nikto_linpeas() {
  echo
  echo "=== TOOLS: nikto & linPEAS ==="
  echo "Overview: nikto scans web servers for misconfigurations. linPEAS enumerates Linux privilege escalation vectors."
  print_install_instructions "nikto, linpeas" "linPEAS is a script (download from GitHub). nikto runs against webserver URLs."
  pause

  echo
  echo "BASIC EXAMPLES"
  echo "1) nikto scan:"
  echo "   nikto -h http://$LAB_TARGET -o nikto_report.txt"
  echo
  echo "2) linPEAS usage (on target shell):"
  echo "   curl -sS https://raw.githubusercontent.com/carlospolop/PEASS-ng/master/linPEAS/linpeas.sh -o linpeas.sh && chmod +x linpeas.sh"
  echo "   ./linpeas.sh | tee linpeas.out"
  echo
  echo "GUIDED EXERCISES"
  echo "A) Run nikto against your lab web app and classify findings by severity."
  echo "B) Run linpeas on a deliberately vulnerable lab VM and document interesting leads."
  pause
  verify_installed nikto || true
}

inventory_summary() {
  echo
  echo "Inventory summary — Tools covered in this tutorial:"
  echo "- nmap"
  echo "- netcat (nc)"
  echo "- tcpdump"
  echo "- wireshark / tshark"
  echo "- metasploit-framework"
  echo "- john (John the Ripper)"
  echo "- hashcat"
  echo "- hydra"
  echo "- burpsuite (Community)"
  echo "- sqlmap"
  echo "- aircrack-ng"
  echo "- ettercap"
  echo "- nikto"
  echo "- linPEAS/linpeas.sh"
  echo
  echo "Each section includes: overview, manual install guidance, examples, and hands-on exercises."
}

safety_rules() {
  echo
  echo "SAFETY & ETHICS"
  echo " - Operate only on systems you own or have explicit authorization to test."
  echo " - Use isolated lab environments: VMs, private VLANs, or containers."
  echo " - Log your actions. Keep copies of outputs for review."
  echo " - Do NOT run exploit modules or crack real user accounts in production."
  echo " - This script supplies guidance only. Responsibility for misuse rests with the operator."
}

show_menu() {
  header
  cat <<'MENU'
Select a tool/module to study (enter number). Type q to quit.

 1) nmap            — Network discovery & NSE
 2) netcat (nc)     — TCP/UDP swiss-army tool
 3) tcpdump         — CLI packet capture
 4) wireshark/tshark — Full packet analysis
 5) metasploit      — Exploit framework (lab only)
 6) john/hashcat    — Password cracking
 7) hydra           — Network logon cracking
 8) burp/sqlmap     — Web proxy & SQLi automation
 9) aircrack/ettercap— Wireless & MITM (lab only)
10) nikto/linPEAS   — Web and Linux enumeration
 i) inventory summary (list all covered tools)
 r) re-print safety & lab rules
 q) quit
MENU
  echo
  read -r -p "Choice: " CHOICE
  case "$CHOICE" in
    1) section_nmap ;;
    2) section_netcat ;;
    3) section_tcpdump ;;
    4) section_wireshark ;;
    5) section_metasploit ;;
    6) section_john_hashcat ;;
    7) section_hydra ;;
    8) section_burp_sqlmap ;;
    9) section_aircrack_ettercap ;;
    10) section_nikto_linpeas ;;
    i) inventory_summary ;;
    r) safety_rules ;;
    q) echo "Exiting." ; exit 0 ;;
    *) echo "Invalid choice." ; sleep 1 ;;
  esac
  pause
}

main_loop() {
  while true; do
    show_menu
  done
}

# Entry point
safety_rules
echo
read -r -p "Have you set LAB_TARGET and confirmed you're in a controlled lab environment? (yes/no): " CONF
if [[ "${CONF,,}" != "yes" ]]; then
  echo "Aborting. Confirm lab setup before proceeding."
  exit 1
fi

main_loop
