Kali Fundamentals Tutorial Package
==================================

Included Files:
- Kali Fundamentals Tutorial.sh : Interactive Kali Linux tutorial script.

Instructions for Use:
1. Download and extract the package.
2. Convert line endings (if on Windows or copied from web):
   dos2unix "Kali Fundamentals Tutorial.sh"
3. Make script executable:
   chmod +x "Kali Fundamentals Tutorial.sh"
4. Run the script:
   bash "Kali Fundamentals Tutorial.sh"
5. Always run in a controlled lab environment (VM, container, isolated network).

Notes:
- Do not run on production systems or public networks.
- This package is for educational purposes only.
